import pandas as pd

from model import sentiment_model, BiLSTM_CRF
import torch
from preprocess import read_data_from_csv, sentiment_dataset,ner_dataset,data_process
from torch.utils.data import DataLoader
from sentiment_task import sentiment_collate_fn
from ner_task import ner_collate_fn
from utils import load_vectors
from torch.utils.data.dataset import random_split

import numpy as np
def predict_sentiment(model_file_name,test_data_loader):
    model = sentiment_model()
    model.load_state_dict(torch.load(model_file_name))
    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
    model.to(device)
    result = []
    with torch.no_grad():
        for i, batch in enumerate(test_data_loader):
            input_ids, token_type_ids, attention_mask, labels = batch
            input_ids = input_ids.to(device, dtype=torch.long)
            token_type_ids = token_type_ids.to(device, dtype=torch.long)
            attention_mask = attention_mask.to(device, dtype=torch.long)
            labels = labels.to(device, dtype=torch.long)
            probs = model(input_ids=input_ids, token_type_ids=token_type_ids, attention_mask=attention_mask)
            result.extend(torch.argmax(probs,-1).squeeze().cpu().numpy().tolist())
    return result

def ner_test_collate_fn(batch):
    input_ids,text_lengths = zip(*batch)

    max_len = max([len(x) for x in input_ids])
    input_ids = [x + [0] * (max_len - len(x)) for x in input_ids]

    text_lengths = np.stack(text_lengths)
    return torch.tensor(input_ids,dtype=torch.long),torch.tensor(text_lengths,dtype=torch.uint8)  ## text_lengths 是不含padding的数据长度

def predict_ner(model,test_data_loader,tag_to_ix):
    result = []
    with torch.no_grad():
        for batch in test_data_loader:
            X,text_lengths = batch
            ret = model.decode(X, text_lengths, tag_to_ix)
            result.extend(ret)
            # precise, reacll, F1 = ner_accuary(batch_tags,label,word2idx,text_lengths)
        return result

if __name__ == '__main__':
    ## predict sentiment
    # _,test_data = read_data_from_csv()
    # test_dataset =  sentiment_dataset(test_data['text'],is_train = False)
    # test_data_loader = DataLoader(
    #                 test_dataset,
    #                 batch_size = 32,
    #                 collate_fn = sentiment_collate_fn,
    #                 shuffle=False
    # )
    # test_data['class'] = predict_sentiment('./model/sentiment_best_model.pt',test_data_loader)
    # print(test_data['class'])
    # test_data.to_csv('sentiment.csv', index=None)
    # test_baseline = pd.read_csv('../test_baseline.csv')
    # test_data = pd.read_csv('./sentiment.csv')
    # BIO = pd.read_csv('./BIO.csv')
    # ret = pd.DataFrame(columns=['id','text','BIO_anno','class'])
    # ret['id'] = list(range(2883))
    # ret['text'] = test_data['text']
    # ret['BIO_anno'] = BIO['BIO_anno']
    # ret['class'] = test_data['class']
    # ret.to_csv('our_submission.csv', index=None)


    ## ner
    fast_text, word2idx = load_vectors("./ff/cc.zh.300.vec")
    train_data, test_data = read_data_from_csv()
    ## datasets
    input_ids, text_lengths = data_process(test_data['text'],word2idx=word2idx, is_train= False)
    tag_to_ix = {'B-BANK': 0, 'I-BANK': 1, 'O': 2, 'B-COMMENTS_N': 3, 'I-COMMENTS_N': 4, 'B-COMMENTS_ADJ': 5,
                 'I-COMMENTS_ADJ': 6, 'B-PRODUCT': 7, 'I-PRODUCT': 8, '<START>': 9, '<STOP>': 10}

    vocab_size = len(word2idx)
    embedding = torch.tensor(fast_text, dtype=torch.float)
    hidden_dim = 500
    epoches = 5
    model = BiLSTM_CRF(vocab_size, tag_to_ix, embedding, hidden_dim)
    optimizer = torch.optim.Adam(model.parameters(), lr=3e-4)
    test_datasets = ner_dataset(input_ids,text_lengths = text_lengths,is_train=False)
    test_data_loader = DataLoader(test_datasets, batch_size=32, num_workers=4, collate_fn=ner_test_collate_fn,
                                   shuffle=False)

    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer,milestones=[20,80],gamma = 0.4)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.load_state_dict(torch.load('./model/ner_best_model.pt'))
    ret = predict_ner(model,test_data_loader,tag_to_ix)







from preprocess import read_data_from_csv,data_process,ner_dataset,bert_ner_dataset
from gensim.models.keyedvectors import FastTextKeyedVectors
import torch
import pandas as pd
import time
from model import BiLSTM_CRF
from torch.optim import lr_scheduler
from nltk import word_tokenize
from transformers import AdamW
from transformers import get_linear_schedule_with_warmup
from torch.utils.data import Dataset, random_split,DataLoader
from transformers import BertTokenizer,BertForTokenClassification
import io
import numpy as np
from torch import nn
from torch.nn.utils.rnn import pad_sequence
from utils import load_vectors,ner_accuary
import os
def ner_collate_fn(batch):
    input_ids,label,text_lengths = zip(*batch)

    max_len = max([len(x) for x in input_ids])
    input_ids = [x + [0] * (max_len - len(x)) for x in input_ids]

    max_len = max([len(x) for x in label])
    label = [x + [0] * (max_len - len(x)) for x in label]


    text_lengths = np.stack(text_lengths)
    return torch.tensor(input_ids,dtype=torch.long),torch.tensor(label,dtype=torch.long),torch.tensor(text_lengths,dtype=torch.uint8)  ## text_lengths 是不含padding的数据长度


tokenizer = BertTokenizer.from_pretrained('bert-base-chinese')
def train(model,optimizer,train_data_loader,valid_data_loader,scheduler,device,tag_to_ix):
    global_step = 0
    model.to(device)
    save_dir = './model'
    for epoch in range(epoches):
        model.train()
        total_loss = []
        for batch in train_data_loader:
            X, label, text_lengths = batch
            X = X.to(device)
            label = label.to(device)
            text_lengths = text_lengths.to(device)
            loss = model.forward(X, label, text_lengths)
            print('loss:', loss)
            loss.backward()
            # nn.utils.clip_grad_norm_(model.parameters(), max_norm=20, norm_type=2)
            optimizer.step()
            scheduler.step()
            global_step += 1
            # if global_step != 0 and global_step % 5 == 0:
            #     ret = model.decode(X, text_lengths, tag_to_ix)
                # precise, reacll, F1 = ner_accuary(batch_tags,label,word2idx,text_lengths)
                # print('epoch:%d,global_step: %d' % (epoch, global_step))
                # print('orgin-tag:', label[0][:text_lengths[0]])
                # print('predict-tag:', ret[0])
            total_loss.append(loss)
        print(sum(total_loss) / len(total_loss))
        with torch.no_grad():
            for batch in valid_data_loader:
                X, label, text_lengths = batch
                X = X.to(device)
                label = label.to(device)
                text_lengths = text_lengths.to(device)
                ret = model.decode(X, text_lengths, tag_to_ix)
                # precise, reacll, F1 = ner_accuary(batch_tags,label,word2idx,text_lengths)
                print("eval------------------------------------")
                print('epoch:%d,global_step: %d' % (epoch, global_step))
                tags = []
                id_to_tag = list(tag_to_ix.keys())
                for id in label[0][:text_lengths[0]]:
                    tags.append(id_to_tag[id])
                print('orgin-tag:', tags)
                print('predict-tag:', ret[0])
        torch.save(model.state_dict(), os.path.join(save_dir, 'ner_best_model.pt'))
if __name__ == '__main__':
    ## 先用BERT试下

    fast_text, word2idx = load_vectors("./ff/cc.zh.300.vec")
    train_data, test_data = read_data_from_csv()
    ## datasets
    input_ids, label_ids, tag_to_ix, text_lengths = data_process(train_data['text'], train_data['BIO_anno'],
                                                                 word2idx=word2idx)
    vocab_size = len(word2idx)
    embedding = torch.tensor(fast_text, dtype=torch.float)
    hidden_dim = 500
    epoches = 10
    model = BiLSTM_CRF(vocab_size, tag_to_ix, embedding, hidden_dim)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)

    train_datasets = ner_dataset(input_ids, label_ids, text_lengths)
    train_datasets,valid_datasets = random_split(train_datasets,[7000,528],generator=torch.Generator().manual_seed(42))
    train_data_loader = DataLoader(train_datasets, batch_size=32, num_workers=4, collate_fn=ner_collate_fn,
                                   shuffle=True)
    valid_data_loader = DataLoader(valid_datasets, batch_size=32, num_workers=4, collate_fn=ner_collate_fn,
                                   shuffle=True)

    scheduler = lr_scheduler.MultiStepLR(optimizer,milestones=[20,80],gamma = 0.95)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    train(model,optimizer,train_data_loader,valid_data_loader,scheduler,device,tag_to_ix)


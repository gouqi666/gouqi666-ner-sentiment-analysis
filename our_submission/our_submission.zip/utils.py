import torch
import io
def load_vectors(fname):
    fin = io.open(fname, 'r', encoding='utf8', newline='\n', errors='ignore')
    n, d = map(int, fin.readline().split())
    data = []
    word2idx = {}
    idx = 0
    for line in fin:
        tokens = line.rstrip().split(' ')
        vector = list(map(float, tokens[1:]))
        if len(vector) != 300:
            continue
        data.append(vector)
        if tokens[0] not in word2idx:
            word2idx[tokens[0]] = idx
            idx += 1
    data.append([0] * 300)
    word2idx['unk'] = idx
    return data,word2idx
def ner_accuary(seq,label,lab2idx,text_lengths): ## label pad后的数据
    gold_num = 0
    predict_num = 0
    correct_num = 0
    idx2lab = list(lab2idx.keys())
    for each_seq,each_lab,length in zip(seq,label,text_lengths):
        flag =False
        each_lab = each_lab[:length]
        for pre,tag in zip(each_seq,each_lab):
            if idx2lab[pre][0] == 'B':
                predict_num += 1
            if idx2lab[tag][0] == 'B':
                gold_num += 1
            if not flag  and idx2lab[tag][0] == 'B' and pre == tag:
                flag = True
            if flag:
                if pre != tag:
                    flag = False
                else:
                    if idx2lab[tag][0] == 'I' or idx2lab[tag][0] == 'O':
                        correct_num += 1
                        flag = False
    if predict_num == 0:
        precise = 0
    else:
        precise = correct_num / predict_num
    if gold_num == 0:
        recall = 0
    else:
        recall = correct_num / gold_num
    if precise == 0 and recall == 0:
        F1 = 0
    else:
        F1 = 2 * precise * recall / (precise + recall)
    return precise, recall, F1

if __name__ == "__main__":
    seq = [[0,1,2,2,0,3,0]] # ['O','B-BANK','I-BANK','I-BANK','O','B-PROUDCT','O']
    label = [[0,1,3,0,0,3,0]] # ['O','B-BANK','B-PROUDCT','O','O','B-PRODUCT','O']
    lab2idx = {'O':0,'B-BANK':1,'I-BANK':2,'B-PRODUCT':3}
    ner_accuary(seq,label,lab2idx)

import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from transformers import  BertModel,BertTokenizer
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
from torch.utils.data import DataLoader
from torch.nn.utils.rnn import pad_sequence
import torch
import os
from utils import load_vectors
from preprocess import data_process,read_data_from_csv,ner_dataset,bert_ner_dataset
class sentiment_model(nn.Module):
    def __init__(self,dropout=None):
        super(sentiment_model,self).__init__()
        self.bertmodel = BertModel.from_pretrained('bert-base-chinese')
        self.dropout = nn.Dropout(dropout if dropout is not None else 0.2)
        # 情感分类任务，0，1，2
        self.classifier = nn.Linear(self.bertmodel.config.hidden_size, 3)
    def forward(self,input_ids,token_type_ids,attention_mask):
        outputs= self.bertmodel(input_ids,token_type_ids=token_type_ids,attention_mask=attention_mask)#
        outputs = outputs.pooler_output
        outputs = self.dropout(outputs)
        #
        logits = self.classifier(outputs)
        return logits


class BERT_CRF(nn.Module):
    def __init__(self,tag_to_ix):
        super(BERT_CRF,self).__init__()
        self.tag_to_ix = tag_to_ix
        self.crf = CRF(self.tag_to_ix)
        self.bert = BertModel.from_pretrained('bert-base-chinese')
        self.target_size = len(tag_to_ix)
        self.dropout = nn.Dropout(0.2)
        # NER
        self.classifier = nn.Linear(self.bert.config.hidden_size, self.target_size)

    def forward(self,inputs_ids,token_type_ids,attention_mask,label,text_lengths):
        feats = self.bert(inputs_ids,token_type_ids,attention_mask)
        outputs = self.dropout(feats.last_hidden_state[1:])
        outputs = self.classifier(outputs)
        loss = self.crf.neg_log_likelihood(outputs, label,text_lengths)
        return loss
    def decode(self,inputs_ids,token_type_ids,attention_mask,text_lengths,tag_to_ix):
        feats = self.bert(inputs_ids,token_type_ids,attention_mask)
        outputs = self.dropout(feats.last_hidden_state[1:])
        outputs = self.classifier(outputs)
        paths = []
        for feats,length in zip(outputs,text_lengths):
            feats = feats[:length]
            path = self.crf.decode(feats,tag_to_ix)
            paths.append(path)
        return paths

class BiLSTM_CRF(nn.Module):
    def __init__(self,vocab_size,tag_to_ix,embedding,hidden_dim):
        super(BiLSTM_CRF,self).__init__()
        self.vocab_size = vocab_size
        self.tag_to_ix = tag_to_ix
        self.embedding = embedding
        self.hidden_dim = hidden_dim
        self.crf = CRF(self.tag_to_ix)
        self.lstm = LSTM(self.vocab_size,self.tag_to_ix,self.embedding,self.hidden_dim)
    def forward(self,data,label,text_lengths):
        feats = self.lstm(data)
        loss = self.crf.neg_log_likelihood(feats, label,text_lengths)
        return loss
    def decode(self,data,text_lengths,tag_to_ix):
        batch_feats = self.lstm(data)
        paths = []
        for feats,length in zip(batch_feats,text_lengths):
            feats = feats[:length]
            path = self.crf.decode(feats,tag_to_ix)
            paths.append(path)

        return paths


class LSTM(nn.Module):
    def __init__(self, vocab_size, tag_to_ix, embedding, hidden_dim):
        super(LSTM, self).__init__()
        self.START_TAG = "<START>"
        self.STOP_TAG = "<STOP>"
        self.embedding_dim = len(embedding[0])
        self.hidden_dim = hidden_dim
        self.vocab_size = vocab_size
        self.tag_to_ix = tag_to_ix
        self.tagset_size = len(tag_to_ix)
        self.word_embeds = nn.Embedding.from_pretrained(embedding)
        self.lstm = nn.LSTM(self.embedding_dim, hidden_dim // 2,
                            num_layers=1, bidirectional=True,batch_first = True)

        self.hidden2tag = nn.Linear(hidden_dim, self.tagset_size)

        self.hidden = self.init_hidden()
    def init_hidden(self):
        return (torch.randn(2, 1, self.hidden_dim // 2),
                torch.randn(2, 1, self.hidden_dim // 2))
    def forward(self,data):
        embeds = self.word_embeds(data)
        packed_output, self.hidden = self.lstm(embeds)
        output = self.hidden2tag(packed_output)
        return output

class CRF(nn.Module):
    def __init__(self,tag_to_ix):
        super(CRF,self).__init__()
        self.tag_to_ix = tag_to_ix
        self.target_size = len(tag_to_ix)
        self.transitions = nn.Parameter(
            torch.randn(self.target_size, self.target_size))
        self.START_TAG = "<START>"
        self.STOP_TAG = "<STOP>"
        # These two statements enforce the constraint that we never transfer
        # to the start tag and we never transfer from the stop tag
        self.transitions.data[:,self.tag_to_ix[self.START_TAG]] = -10000  # 从行转到列
        self.transitions.data[self.tag_to_ix[self.STOP_TAG], :] = -10000
    def forward(self,feats):
        previous = None
        for i,feat in enumerate(feats):
            if i == 0:
                previous = feat  + self.transitions.data[self.tag_to_ix[self.START_TAG],:]                   ##  START_TAG到第一个状态的转移概率
            else:
                previous = previous.view(1, -1).expand(self.target_size, self.target_size).transpose(1, 0)
                feat = feat.view(1,-1).expand(self.target_size,self.target_size)
                score = previous + feat + self.transitions.data
                max_score = torch.max(score,dim=0).values # 每一列的最大值
                # print("previous:",previous)
                # print("feat:",feat)
                # print("score:",score)
                # print("max_score:",max_score)
                max_score_broadcast = max_score.view(1,-1).expand(self.target_size,self.target_size) ## 防止结果是inf
                # print("max_score_broadcast:",max_score_broadcast)
                score_exp = torch.exp(score - max_score_broadcast)
                # print("score_exp:",score_exp)
                previous = max_score + torch.log(torch.sum(score_exp,dim=0))
                # Compute log sum exp in a numerically stable way for the forward algorithm
                # 前向算法是不断累积之前的结果，这样就会有个缺点
                # 指数和累积到一定程度后，会超过计算机浮点值的最大值，变成inf，这样取log后也是inf
                # 为了避免这种情况，用一个合适的值clip去提指数和的公因子，这样就不会使某项变得过大而无法计算
                # SUM = log(exp(s1)+exp(s2)+...+exp(s100))
                #     = log{exp(clip)*[exp(s1-clip)+exp(s2-clip)+...+exp(s100-clip)]}
                #     = clip + log[exp(s1-clip)+exp(s2-clip)+...+exp(s100-clip)]
                # where clip=max

        max_previous = torch.max(previous,dim=0).values ## 防止结果是inf
        # print('max_previous:',max_previous)
        forward_score =  max_previous +  torch.log(torch.sum(torch.exp(previous - max_previous.view(1,-1).expand(1,self.target_size))))
        # print(torch.exp(previous))
        # print(torch.sum(torch.exp(previous)))
        return forward_score
    def gold_score(self,feats, tags):
        score = 0
        for i,(feat,tag) in enumerate(zip(feats,tags)):
            score += feat[tag]
            if i == 0:
                score += self.transitions.data[self.tag_to_ix[self.START_TAG]][tag]  ##  START_TAG到第一个状态的转移概率
            else:
                if self.transitions.data[tags[i-1]][tag] == -10000.:
                    pass
                    # print('feats',feats)
                    # print('tags',tags)
                    # print(self.transitions.data)
                score += self.transitions.data[tags[i-1]][tag]
        score += self.transitions.data[tags[i]][self.tag_to_ix[self.STOP_TAG]]   ##  最后一个状态到STOP_TAG的转移概率
        return score
    def neg_log_likelihood(self,feats,label,text_lengths):
        loss = 0
        for feat,lab,length in zip(feats,label,text_lengths):
            forward_score = self.forward(feat[:length])
            gold_score = self.gold_score(feat[:length],lab[:length])
            loss += forward_score - gold_score
        return loss / feats.size(0)
    def decode(self,feats,tag_to_ix):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        viterbi_score = torch.tensor(torch.full((1, self.target_size), -10000.),device = device)
        viterbi_score[0][self.tag_to_ix[self.START_TAG]] = 0
        backpointers = []
        for i,feat in enumerate(feats):
            each_back = []
            each_viterbi = []
            for j in range(self.target_size):
                print(viterbi_score.device)
                print(feat)
                print(self.transitions.data)
                cur_score = viterbi_score + feat + self.transitions.data[:,j]  ##  算了START_TAG到第一个状态的转移概率
                max_element = torch.max(cur_score,-1)
                each_back.append(max_element.indices)
                each_viterbi.append(max_element.values)
            backpointers.append(each_back)
            viterbi_score = torch.tensor(each_viterbi,device=device)
        viterbi_score += self.transitions.data[:,self.tag_to_ix[self.STOP_TAG]] ##  算了最后一个状态到STOP_TAG的转移概率

        ix_to_lab = list(tag_to_ix.keys())
        last = torch.max(viterbi_score,0).indices
        path = [ix_to_lab[last.item()]]
        for i in range(len(backpointers)-1,0,-1):
            last = backpointers[i][last]
            path.append(ix_to_lab[last.item()])

        return list(reversed(path))

tokenizer = BertTokenizer.from_pretrained('bert-base-chinese')
def bert_collate_fn(batch,token_id=tokenizer.pad_token_id,token_type_id=tokenizer.pad_token_type_id):
    inputs_ids,token_type_ids,attention_mask,labels,text_lengths = zip(*batch)
    max_len = max([len(seq_a) for seq_a in inputs_ids]) #这里我使用的是一个batch中text_a或者是text_b的最大长度作为max_len,也可以自定义长度
    inputs_ids = [seq + [token_id]*(max_len-len(seq)) for seq in inputs_ids]
    token_type_ids = [seq + [token_type_id]*(max_len-len(seq)) for seq in token_type_ids]
    attention_mask = [seq + [0]*(max_len-len(seq)) for seq in attention_mask]
    max_len = max([len(seq_a) for seq_a in labels])
    labels = [seq + [-1]*(max_len-len(seq)) for seq in labels]
    return torch.tensor(inputs_ids,dtype = torch.long),torch.tensor(token_type_ids,dtype = torch.long),torch.tensor(attention_mask,dtype = torch.long),torch.tensor(labels,dtype=torch.long),torch.tensor(text_lengths,dtype=torch.long)

if __name__ == '__main__':

    # test BiLSTM_CRF
    # fast_text,word2idx = load_vectors("../../ff/cc.zh.300.vec")  # 词向量位置
    # train_data,test_data = read_data_from_csv()
    # ## datasets
    # input_ids, label_ids, tag_to_ix, text_lengths = data_process(train_data['text'], train_data['BIO_anno'],word2idx = word2idx)
    # vocab_size = len(word2idx)
    # embedding = torch.tensor(fast_text,dtype=torch.float)
    # hidden_dim = 100
    # model = BiLSTM_CRF(vocab_size, tag_to_ix, embedding, hidden_dim)
    # optimizer = torch.optim.Adam(model.parameters(), lr=3e-4)
    #
    # train_datasets = ner_dataset(input_ids,label_ids,text_lengths)
    # train_data_loader = DataLoader(train_datasets, batch_size=32, num_workers=4,collate_fn=ner_collate_fn, shuffle=True)
    # model.train()
    # for batch in train_data_loader:
    #     optimizer.zero_grad()
    #     X,label,text_lengths = batch
    #     loss = model.forward(X,label,text_lengths)
    #     print('loss:',loss)
    #     ret = model.decode(X,text_lengths,tag_to_ix)
    #     print(ret[0])
    #     loss.backward()
    #     nn.utils.clip_grad_norm_(model.parameters(), max_norm=20, norm_type=2)
    #     optimizer.step()

    #test BERT_CRF
    train_data,test_data = read_data_from_csv()
    tokenizer = BertTokenizer.from_pretrained('bert-base-chinese')
    tag_to_ix = {'B-BANK': 0, 'I-BANK': 1, 'O': 2, 'B-COMMENTS_N': 3, 'I-COMMENTS_N': 4, 'B-COMMENTS_ADJ': 5, 'I-COMMENTS_ADJ': 6, 'B-PRODUCT': 7, 'I-PRODUCT': 8, '<START>': 9, '<STOP>': 10}
    ## datasets
    train_datasets = bert_ner_dataset(train_data['text'],train_data['BIO_anno'],tag_to_ix)
    train_datasets,valid_datasets = torch.utils.data.random_split(train_datasets,[7000,528],generator=torch.Generator().manual_seed(42))
    train_data_loader = DataLoader(
                    train_datasets,
                    batch_size = 32,
                    collate_fn = bert_collate_fn,
                    shuffle=True
    )
    valid_data_loader = DataLoader(
                    valid_datasets,
                    batch_size = 32,
                    collate_fn = bert_collate_fn,
                    shuffle=True
    )
    ## train parameters
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(device)

    model = BERT_CRF(tag_to_ix)
    criterion = nn.CrossEntropyLoss()
    criterion = criterion.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=3e-6)
    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[20, 80], gamma=0.4)
    model = model.to(device)
    ckpt_dir = './'

    # train
    epoches = 5
    global_step = 0
    for epoch in range(1, epoches + 1):
        model.train()
        train_loss = 0
        total_acc = []
        for step, batch in enumerate(train_data_loader, start=1):
            optimizer.zero_grad()
            input_ids, token_type_ids, attention_mask, labels,text_lengths = batch
            input_ids = input_ids.to(device, dtype=torch.long)
            token_type_ids = token_type_ids.to(device, dtype=torch.long)
            attention_mask = attention_mask.to(device, dtype=torch.long)
            labels = labels.to(device, dtype=torch.long)
            text_lengths = text_lengths.to(device,dtype=torch.long)
            # 喂数据给model
            loss = model.forward(input_ids,token_type_ids,attention_mask,labels,text_lengths)
            # 计算损失函数值
            train_loss += loss
            loss.backward()
            print('loss:',loss)
            optimizer.step()
            scheduler.step()
            global_step += 1
        print('epoch:%d,mean_loss:%.5f' % (
        epoch, train_loss / len(train_data_loader)))
        # 评估当前训练的模型
        model.eval()
        save_dir = os.path.join(ckpt_dir, "model")
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        with torch.no_grad():
            torch.cuda.empty_cache()
            total_acc = []
            for i, batch in enumerate(valid_data_loader):
                input_ids, token_type_ids, attention_mask, labels, text_lengths = batch
                input_ids = input_ids.to(device, dtype=torch.long)
                token_type_ids = token_type_ids.to(device, dtype=torch.long)
                attention_mask = attention_mask.to(device, dtype=torch.long)
                labels = labels.to(device, dtype=torch.long)
                text_lengths = text_lengths.to(device, dtype=torch.long)
                # 喂数据给model
                ret = model.decode(input_ids, token_type_ids, attention_mask,text_lengths,tag_to_ix)
                tags = []
                id_to_tag = list(tag_to_ix.keys())
                for id in labels[0][:text_lengths[0]]:
                    tags.append(id_to_tag[id])
                print('orgin-tag:', tags)
                print('predict-tag:', ret[0])
            torch.save(model.state_dict(), os.path.join(save_dir, 'ner_bert_best_model.pt'))










